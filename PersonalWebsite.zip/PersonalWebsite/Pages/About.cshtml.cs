using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PhillipSuhPortfolio.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
