using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PhillipSuhPortfolio.Pages
{
    public class SkillsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
